#include "emergencycenter.h"

EmergencyCenter::EmergencyCenter()
{
}
