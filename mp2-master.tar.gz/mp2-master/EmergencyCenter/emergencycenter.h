#ifndef EMERGENCYCENTER_H
#define EMERGENCYCENTER_H

#include "EmergencyCenter_global.h"

class EMERGENCYCENTER_EXPORT EmergencyCenter
{
public:
    EmergencyCenter();
};

#endif // EMERGENCYCENTER_H
